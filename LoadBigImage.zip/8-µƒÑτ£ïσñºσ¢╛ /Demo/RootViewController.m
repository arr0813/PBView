//
//  RootViewController.m
//  Demo
//
//  Created by Zontonec on 16/11/11.
//  Copyright © 2016年 Zontonec. All rights reserved.
//

#import "RootViewController.h"
#import "PhotoBrowseController.h"

//屏幕宽高
#define SCREENWIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREENHEIGHT [[UIScreen mainScreen] bounds].size.height

@interface RootViewController ()

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [button setTitle:@"弹键盘" forState:UIControlStateNormal];
    
    [button setFrame:CGRectMake(100, 100, [[UIScreen mainScreen] bounds].size.width - 200 , 50)];
    
    [button addTarget:self action:@selector(buttonDidPress) forControlEvents:UIControlEventTouchUpInside];
    
    [button setBackgroundColor:[UIColor redColor]];
    
    [self.view addSubview:button];
    
    
}
-(void)buttonDidPress{
    
    NSString * URL = @"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1489743921759&di=d0eb6c9c78d7446897b846706698b7cd&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fbaike%2Fpic%2Fitem%2F3b292df5e0fe992536be579530a85edf8cb17140.jpg";
    
    /*
     
     参数1：photosArr --- 保存URL的数组  @[@"URL1",@"URL2"]
     参数2：currentIndex --- 当前为第几张图片 从0开始
     参数3：way --- 进入当前Controller的方式（传1为通过导航栏push的的方式，传其他为present的方式）
     
     */
    
    PhotoBrowseController * PBC = [[PhotoBrowseController alloc]initWithAllPhotosArray:@[URL,URL,URL,URL,URL,URL,URL,URL,URL,URL,URL] currentIndex:5 way:0];
    
    [self presentViewController:PBC animated:YES completion:nil];
    //[self.navigationController pushViewController:PBC animated:YES];
}
@end
