//
//  BabyPhotosShareView.m
//  BGH-family
//
//  Created by Sunny on 17/2/23.
//  Copyright © 2017年 Zontonec. All rights reserved.
//

#import "PhotosShareView.h"

@implementation PhotosShareView

+ (instancetype)photosShareView
{
    return [[[NSBundle mainBundle] loadNibNamed:@"PhotosShareView" owner:nil options:nil] firstObject];
}

@end
