//
//  PhotoBrowseController.m
//  BGH-family
//
//  Created by Sunny on 17/2/24.
//  Copyright © 2017年 Zontonec. All rights reserved.
//

#import "PhotoBrowseController.h"
#import "PhotoBrowseCell.h"
#import "UIView+Layout.h"
#import "PhotosShareView.h"
#import "PhotoBrowseModel.h"
#import "SVProgressHUD.h"

@interface PhotoBrowseController () <UICollectionViewDataSource, UICollectionViewDelegate, UIScrollViewDelegate>

/** collectionView */
@property(nonatomic, strong) UICollectionView *collectionView;
/** 选择按钮 */
@property(nonatomic, strong) UIButton *selectedBtn;
/** 页码 */
@property(nonatomic, strong) UILabel *pageLabel;
/** 分享背景View */
@property(nonatomic, strong) UIView *shareBgView;
/** PhotosShareView */
@property(nonatomic, strong) PhotosShareView *shareView;
/** 模型数组 */
@property(nonatomic, strong) NSMutableArray *photoBrowseModelArr;
/** 当前显示的Index */
@property(nonatomic, assign) NSInteger currentIndex;
/** 当前的image */
@property(nonatomic, strong) UIImage *currentImage;
/** 当前indexPath */
@property(nonatomic, strong) NSIndexPath *currentIndexPath;
/** 进入查看大图的Controller的方式 */
@property(nonatomic, assign) NSInteger way;

@end

static NSString *ID = @"PhotoBrowseCell";

@implementation PhotoBrowseController

- (instancetype)initWithAllPhotosArray:(NSArray *)photosArr currentIndex:(NSInteger)currentIndex way:(NSInteger)way
{
    if (self = [super init])
    {
        self.way = way ;
        
        for (NSString *url in photosArr)
        {
            PhotoBrowseModel *model = [PhotoBrowseModel photoBrowseModelWith:url];
            [self.photoBrowseModelArr addObject:model];
        }
        self.currentIndex = currentIndex;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self.view addSubview:self.collectionView];
    [self.view addSubview:self.selectedBtn];
    [self.view addSubview:self.pageLabel];
    [self.view addSubview:self.shareBgView];
    [self.view addSubview:self.shareView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
    [UIApplication sharedApplication].statusBarHidden = YES;
    
    [self.collectionView setContentOffset:CGPointMake((self.view.pf_width + 20) * self.currentIndex, 0) animated:NO];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
    [UIApplication sharedApplication].statusBarHidden = NO;
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

#pragma mark - 懒加载

- (UICollectionView *)collectionView
{
    if (!_collectionView)
    {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        layout.itemSize = CGSizeMake(self.view.pf_width + 20, self.view.pf_height);
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 0;
        
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(-10, 0, self.view.pf_width + 20, self.view.pf_height) collectionViewLayout:layout];
        _collectionView.backgroundColor = [UIColor blackColor];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.pagingEnabled = YES;
        _collectionView.scrollsToTop = NO;
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.contentOffset = CGPointMake(0, 0);
        _collectionView.contentSize = CGSizeMake(self.photoBrowseModelArr.count * (self.view.pf_width + 20), 0);
        [_collectionView registerClass:[PhotoBrowseCell class] forCellWithReuseIdentifier:ID];
    }
    return _collectionView;
}

- (UIButton *)selectedBtn
{
    if (!_selectedBtn)
    {
        _selectedBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _selectedBtn.frame = CGRectMake(self.view.pf_width - 64, 29, 44, 25);
        [_selectedBtn setImage:[UIImage imageNamed:@"babyalbum_btn_more"] forState:UIControlStateNormal];
        [_selectedBtn addTarget:self action:@selector(clickSelectedBtn) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _selectedBtn;
}

- (UILabel *)pageLabel
{
    if (!_pageLabel)
    {
        _pageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 35, self.view.pf_width, 22)];
        _pageLabel.text = [NSString stringWithFormat:@"%zd/%zd", self.currentIndex + 1, self.photoBrowseModelArr.count];
        _pageLabel.textColor = [UIColor whiteColor];
        _pageLabel.textAlignment = NSTextAlignmentCenter;
        _pageLabel.font = [UIFont systemFontOfSize:20.0];
        _pageLabel.backgroundColor = [UIColor clearColor];
    }
    return _pageLabel;
}

- (NSMutableArray *)photoBrowseModelArr
{
    if (!_photoBrowseModelArr)
    {
        _photoBrowseModelArr = [NSMutableArray array];
    }
    return _photoBrowseModelArr;
}

- (PhotosShareView *)shareView
{
    if (!_shareView)
    {
        _shareView = [PhotosShareView photosShareView];
        _shareView.frame = CGRectMake(0, self.view.pf_height, self.view.pf_width, 260);
        
        UITapGestureRecognizer *tapGR2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapSaveLocalLabel)];
        [_shareView.saveLocalLabel addGestureRecognizer:tapGR2];
        
        UITapGestureRecognizer *tapGR3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapShareQQfriend)];
        [_shareView.shareQQfriend addGestureRecognizer:tapGR3];
        
        UITapGestureRecognizer *tapGR4 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapShareQQzone)];
        [_shareView.shareQQzone addGestureRecognizer:tapGR4];
        
        UITapGestureRecognizer *tapGR5 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapShareWechatFriend)];
        [_shareView.shareWechatFriend addGestureRecognizer:tapGR5];
        
        UITapGestureRecognizer *tapGR6 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapShareFriendCircle)];
        [_shareView.shareFriendCircle addGestureRecognizer:tapGR6];
        
        UITapGestureRecognizer *tapGR7 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapShareXinlang)];
        [_shareView.shareXinlang addGestureRecognizer:tapGR7];
        
        [_shareView.cancelBtn addTarget:self action:@selector(tapCancelBtn) forControlEvents:UIControlEventTouchUpInside];
    }
    return _shareView;
}

- (UIView *)shareBgView
{
    if (!_shareBgView)
    {
        _shareBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.pf_width, self.view.pf_height)];
        _shareBgView.backgroundColor = [UIColor blackColor];
        _shareBgView.alpha = 0.5;
        _shareBgView.hidden = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapShareBgView:)];
        [_shareBgView addGestureRecognizer:tap];
    }
    return _shareBgView;
}

#pragma mark - shareView event

- (void)clickSelectedBtn
{
    [UIView animateWithDuration:0.3 animations:^{
        self.shareBgView.hidden = NO;
        self.shareView.frame = CGRectMake(0, self.view.pf_height - 260, self.view.pf_width, 260);
    }];
}

- (void)tapSaveLocalLabel
{
    [UIView animateWithDuration:0.3 animations:^{
        self.shareBgView.hidden = YES;
        self.shareView.frame = CGRectMake(0, self.view.pf_height, self.view.pf_width, 260);
    }];
    
    if (self.currentImage)
    {
        UIImageWriteToSavedPhotosAlbum(self.currentImage, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
    }
}
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    if (error)
    {
        [SVProgressHUD showErrorWithStatus:@"保存失败"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
    }
    else
    {
        [SVProgressHUD showSuccessWithStatus:@"已保存到相册"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
    }
}

- (void)tapShareQQfriend
{
    NSLog(@"分享QQ好友");
}

- (void)tapShareQQzone
{
    NSLog(@"分享QQ空间");
}

- (void)tapShareWechatFriend
{
    NSLog(@"分享微信好友");
}

- (void)tapShareFriendCircle
{
    NSLog(@"分享朋友圈");
}

- (void)tapShareXinlang
{
    NSLog(@"分享新浪微博");
}

- (void)tapCancelBtn
{
    [UIView animateWithDuration:0.3 animations:^{
        self.shareBgView.hidden = YES;
        self.shareView.frame = CGRectMake(0, self.view.pf_height, self.view.pf_width, 260);
    }];
}

- (void)tapShareBgView:(UITapGestureRecognizer *)tapGR
{
    [UIView animateWithDuration:0.3 animations:^{
        self.shareBgView.hidden = YES;
        self.shareView.frame = CGRectMake(0, self.view.pf_height, self.view.pf_width, 260);
    }];
}

#pragma mark - <UICollectionViewDataSource>

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.photoBrowseModelArr.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    PhotoBrowseCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
    
    cell.model = self.photoBrowseModelArr[indexPath.row];
    
    __weak typeof(self) weakSelf = self;
    cell.singleTapGestureBlock = ^(){
        
        if (weakSelf.way == 1) {
            
            [weakSelf.navigationController popViewControllerAnimated:YES];
        }
        else {
            
            [weakSelf dismissViewControllerAnimated:YES completion:nil];
        }
    };
    
    self.currentImage = cell.browseView.imageView.image;
    self.currentIndexPath = indexPath;
    
    return cell;
}

#pragma mark - <UICollectionViewDelegate>

- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell isKindOfClass:[PhotoBrowseCell class]])
    {
        [(PhotoBrowseCell *)cell recoverSubviews];
    }
}

- (void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell isKindOfClass:[PhotoBrowseCell class]])
    {
        [(PhotoBrowseCell *)cell recoverSubviews];
    }
}

#pragma mark - <UIScrollViewDelegate>

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //设置页码Label
    NSInteger page = scrollView.contentOffset.x / (self.view.pf_width + 20);
    self.pageLabel.text = [NSString stringWithFormat:@"%zd/%zd", page + 1, self.photoBrowseModelArr.count];
}

- (void)dealloc
{
    NSLog(@"%s", __func__);
}

@end
