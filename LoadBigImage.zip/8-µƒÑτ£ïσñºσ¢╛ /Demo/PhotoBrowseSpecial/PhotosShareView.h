//
//  BabyPhotosShareView.h
//  BGH-family
//
//  Created by Sunny on 17/2/23.
//  Copyright © 2017年 Zontonec. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotosShareView : UIView


@property (weak, nonatomic) IBOutlet UILabel *saveBabyPhotosLabel;
@property (weak, nonatomic) IBOutlet UILabel *saveLocalLabel;
@property (weak, nonatomic) IBOutlet UIView *shareQQfriend;
@property (weak, nonatomic) IBOutlet UIView *shareQQzone;
@property (weak, nonatomic) IBOutlet UIView *shareWechatFriend;
@property (weak, nonatomic) IBOutlet UIView *shareFriendCircle;
@property (weak, nonatomic) IBOutlet UIView *shareXinlang;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;









//初始化方法 设置frame时 高度设为320
+ (instancetype)photosShareView;

@end
